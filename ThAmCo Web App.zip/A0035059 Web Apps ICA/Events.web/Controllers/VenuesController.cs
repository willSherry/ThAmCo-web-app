﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using ThAmCo.Events.DTO;

namespace Events.web.Controllers
{
    public class VenuesController : Controller
    {
        HttpClient client;
        public VenuesController()
        {
            client = new HttpClient();
            client.BaseAddress = new System.Uri("https://localhost:44352/");
            client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
        }

        // GET: VenuesController
        public async Task<ActionResult> Index()
        {
            IEnumerable<VenueDTO> venues = new List<VenueDTO>();

            HttpResponseMessage response = await client.GetAsync("api/Venues");
            if (response.IsSuccessStatusCode)
            {
                venues = await response.Content.ReadAsAsync<IEnumerable<VenueDTO>>();
            }
            else
            {
                Debug.WriteLine("Index received a bad response from the web service.");
            }
            return View(venues.ToList());
        }

        // GET: VenuesController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: VenuesController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: VenuesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VenuesController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: VenuesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VenuesController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: VenuesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
