﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ThAmCo.Events.Models;

namespace Events.web.Controllers
{
    public class StaffingsController : Controller
    {
        private readonly EventContext _context;

        public StaffingsController(EventContext context)
        {
            _context = context;
        }

        // GET: Staffings
        public async Task<IActionResult> Index()
        {
            var eventContext = _context.Staffings.Include(s => s.Event).Include(s => s.Staff);
            return View(await eventContext.ToListAsync());
        }

      

        // GET: Staffings/Create
        public IActionResult Create()
        {
            ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventTitle");
            ViewData["StaffId"] = new SelectList(_context.Staffs, "StaffId", "StaffName");
            return View();
        }

        // POST: Staffings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StaffId,EventId")] Staffing staffing)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(staffing);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }catch (Exception ex)
            {

            }

            ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventTitle", staffing.EventId);
            ViewData["StaffId"] = new SelectList(_context.Staffs, "StaffId", "StaffName", staffing.StaffId);
            return View(staffing);
        }



  

        // GET: Staffings/Delete/5
        public async Task<IActionResult> Delete(int? StaffId, int? EventId)
        {
            if (StaffId == null || EventId == null)
            {
                return NotFound();
            }

            var staffing = await _context.Staffings
                .Include(s => s.Event)
                .Include(s => s.Staff)
                .FirstOrDefaultAsync(m => m.StaffId == StaffId && m.EventId == EventId);
            if (staffing == null)
            {
                return NotFound();
            }

            return View(staffing);
        }

        // POST: Staffings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int StaffId, int EventId)
        {
            var staffing = await _context.Staffings.FindAsync(StaffId, EventId);
            _context.Staffings.Remove(staffing);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StaffingExists(int id)
        {
            return _context.Staffings.Any(e => e.StaffId == id);
        }
    }
}
