﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ThAmCo.Events.Models;

namespace Events.web.Controllers
{
    public class GuestBookingsController : Controller
    {
        private readonly EventContext _context;

        public GuestBookingsController(EventContext context)
        {
            _context = context;
        }

        // GET: GuestBookings
        public async Task<IActionResult> Index()
        {
            var eventContext = _context.GuestBookings.Include(g => g.Customer).Include(g => g.Event);
            return View(await eventContext.ToListAsync());
        }


        // GET: GuestBookings/Create
        public IActionResult Create()
        {
            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "CustomerName");
            ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventTitle");
            return View();
        }

        // POST: GuestBookings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerId,EventId,Attendance")] GuestBooking guestBooking)
        {
            try 
            {
                if (ModelState.IsValid)
                {
                    _context.Add(guestBooking);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {

            }
            

            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "CustomerName", guestBooking.CustomerId);
            ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventTitle", guestBooking.EventId);
            return View(guestBooking);
        }


        // GET: GuestBookings/Delete/5
        public async Task<IActionResult> Delete(int? CustomerId, int? EventId)
        {
            if (CustomerId == null | EventId == null)
            {
                return NotFound();
            }

            var guestBooking = await _context.GuestBookings
                .Include(g => g.Customer)
                .Include(g => g.Event)
                .FirstOrDefaultAsync(m => m.CustomerId == CustomerId && m.EventId == EventId);
            if (guestBooking == null)
            {
                return NotFound();
            }

            return View(guestBooking);
        }

        // POST: GuestBookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int CustomerId, int? EventId)
        {
            var guestBooking = await _context.GuestBookings.FindAsync(CustomerId, EventId);
            _context.GuestBookings.Remove(guestBooking);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool GuestBookingExists(int id)
        {
            return _context.GuestBookings.Any(e => e.CustomerId == id);
        }
    }
}
