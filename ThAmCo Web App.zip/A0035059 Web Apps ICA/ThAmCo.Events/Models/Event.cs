﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ThAmCo.Events.Models
{
    public class Event
    {

        public int EventId { get; set; }


        [Required, MaxLength(50)]
        public string EventTitle { get; set; }


        [Required, DataType(DataType.Date), Display(Name = "Event Date")]
        public DateTime Date { get; set; }

        [Required, MaxLength(50), Display(Name = "Event Type")]
        public string EventType { get; set; }

        [Display(Name = "Food Booking Reference")]
        public int FoodBookingReference { get; set; } 
       
    }
}
