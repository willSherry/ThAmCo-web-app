﻿using System.ComponentModel.DataAnnotations;

namespace ThAmCo.Events.Models
{
    public class GuestBooking
    {

        public int CustomerId { get; set; }

        public int EventId  { get; set; }

        public bool Attendance { get; set; }

        public Customer Customer { get; set; }

        public Event Event { get; set; }

    }
}
