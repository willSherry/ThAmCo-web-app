﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ThAmCo.Events.Models
{
    public class Customer
    {
        [Display(Name = "Customer ID")]
        public int CustomerId { get; set; }


        [Required, MaxLength(50), Display(Name = "Customer Name")]
        public string CustomerName { get; set; }


        [Display(Name = "Phone Number")]
        public int PhoneNumber {  get; set; }

        [Required]
        public char Attendance { get; set; }

    }
    
}
