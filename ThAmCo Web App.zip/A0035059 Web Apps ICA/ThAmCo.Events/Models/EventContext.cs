﻿using Microsoft.EntityFrameworkCore;
using System;
using ThAmCo.Events.DTO;

namespace ThAmCo.Events.Models
{
    public class EventContext : DbContext
    {

        public DbSet<Event> Events {  get; set; }

        public DbSet<Customer> Customers { get; set; }

        public DbSet<Staff> Staffs {  get; set;}

        public DbSet<Staffing> Staffings { get; set; }

        public DbSet<GuestBooking> GuestBookings { get; set; }

        public EventContext(DbContextOptions<EventContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Prevent Cascade Delete
            builder.Entity<GuestBooking>()
                .HasOne(m => m.Customer)
                .WithMany()
                .HasForeignKey(m => m.CustomerId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<GuestBooking>()
                .HasOne(m => m.Event)
                .WithMany()
                .HasForeignKey(m => m.EventId)
                .OnDelete(DeleteBehavior.Cascade);

            // Composite Keys
            builder.Entity<GuestBooking>()
                .HasKey(a => new { a.CustomerId, a.EventId });

            builder.Entity<Staffing>()
                .HasKey(a => new { a.StaffId, a.EventId });

            // Handle the many to many
            builder.Entity<GuestBooking>()
                .HasOne(m => m.Customer)
                .WithMany()
                .HasForeignKey(m => m.CustomerId);

            builder.Entity<GuestBooking>()
                .HasOne(m => m.Event)
                .WithMany()
                .HasForeignKey(m => m.EventId);

            builder.Entity<Staffing>()
                .HasOne(m => m.Event)
                .WithMany()
                .HasForeignKey(m => m.EventId);

            builder.Entity<Staffing>()
                .HasOne(m => m.Staff)
                .WithMany()
                .HasForeignKey(m => m.StaffId);


            // Seed Data
            builder.Entity<Customer>().HasData(
                new Customer { CustomerId = 1, CustomerName = "Name1", PhoneNumber = 234, Attendance = 'Y' },
                new Customer { CustomerId = 2, CustomerName = "Name2", PhoneNumber = 123234, Attendance = 'N' },
                new Customer { CustomerId = 3, CustomerName = "Name3", PhoneNumber = 234312, Attendance = 'N' },
                new Customer { CustomerId = 4, CustomerName = "Name4", PhoneNumber = 234322, Attendance = 'Y' }
                );

            builder.Entity<Event>().HasData(
                new Event { EventId = 1, FoodBookingReference = 1, Date = new DateTime(2019, 11, 12), EventTitle = "Event 1", EventType = "Wedding" },
                new Event { EventId = 2, FoodBookingReference = 2, Date = new DateTime(2021, 12, 31), EventTitle = "Event 2", EventType = "Reception" },
                new Event { EventId = 3, FoodBookingReference = 3, Date = new DateTime(2022, 3, 17), EventTitle = "Event 3", EventType = "Dinner" },
                new Event { EventId = 4, FoodBookingReference = 4, Date = new DateTime(2022, 5, 2), EventTitle = "Event 4", EventType = "Brunch" },
                new Event { EventId = 5, FoodBookingReference = 5, Date = new DateTime(2022, 6, 2), EventTitle = "Event 5", EventType = "Breakfast" }
                );

            builder.Entity<GuestBooking>().HasData(
                new GuestBooking { CustomerId = 1, EventId = 2 , Attendance = true},
                new GuestBooking { CustomerId = 2, EventId = 2 , Attendance = true },
                new GuestBooking { CustomerId = 2, EventId = 3 , Attendance = false }
                );

            builder.Entity<Staff>().HasData(
                new Staff { StaffId = 1, StaffName = "Marc", StaffType = "First Aid" },
                new Staff { StaffId = 2, StaffName = "Sophie", StaffType = "Waiter" },
                new Staff { StaffId = 3, StaffName = "Juan", StaffType = "Caterer" },
                new Staff { StaffId = 4, StaffName = "Elena", StaffType = "First Aid" }
                );

            builder.Entity<Staffing>().HasData(
                new Staffing { StaffId = 1, EventId = 2 },
                new Staffing { StaffId = 2, EventId = 2 },
                new Staffing { StaffId = 3, EventId = 2 },
                new Staffing { StaffId = 4, EventId = 1 },
                new Staffing { StaffId = 2, EventId = 1 },
                new Staffing { StaffId = 4, EventId = 5 }
                );

        }

        public DbSet<ThAmCo.Events.DTO.VenueDTO> VenueDTO { get; set; }
        public DbSet<ThAmCo.Events.DTO.EventTypeDTO> EventTypeDTO { get; set; }
    }
}
