﻿using System.ComponentModel.DataAnnotations;

namespace ThAmCo.Events.Models
{
    public class Staff
    {
        public int StaffId {  get; set; }

        [Required, Display(Name = "Staff Name")]
        public string StaffName {  get; set; }

        [Required, Display(Name = "Staff Type")]
        public string StaffType { get; set; }
    }
}
