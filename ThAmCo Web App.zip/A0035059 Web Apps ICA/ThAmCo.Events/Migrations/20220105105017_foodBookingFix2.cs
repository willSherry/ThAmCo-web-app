﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ThAmCo.Events.Migrations
{
    public partial class foodBookingFix2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "FoodBookingId",
                table: "Events",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "Events",
                keyColumn: "EventId",
                keyValue: 5,
                columns: new[] { "Date", "EventType", "FoodBookingId" },
                values: new object[] { new DateTime(2022, 6, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "Breakfast", 5 });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "FoodBookingId",
                table: "Events",
                type: "int",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.UpdateData(
                table: "Events",
                keyColumn: "EventId",
                keyValue: 5,
                columns: new[] { "Date", "EventType", "FoodBookingId" },
                values: new object[] { new DateTime(2002, 6, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Prom", null });
        }
    }
}
