﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThAmCo.Events.Migrations
{
    public partial class attendance : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "Attendance",
                table: "GuestBookings",
                nullable: false,
                defaultValue: false);

            migrationBuilder.UpdateData(
                table: "GuestBookings",
                keyColumns: new[] { "CustomerId", "EventId" },
                keyValues: new object[] { 1, 2 },
                column: "Attendance",
                value: true);

            migrationBuilder.UpdateData(
                table: "GuestBookings",
                keyColumns: new[] { "CustomerId", "EventId" },
                keyValues: new object[] { 2, 2 },
                column: "Attendance",
                value: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Attendance",
                table: "GuestBookings");
        }
    }
}
