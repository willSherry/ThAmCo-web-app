﻿USE [Events] 
USE [Catering]
GO

select t1.FoodBookingId, t1.FoodBookingId, t2.FoodBookingId
from Catering.dbo.foodBookings as t1
inner join Events.dbo.FoodBooking as t2 on t1.FoodBookingId = t2.FoodBookingId

