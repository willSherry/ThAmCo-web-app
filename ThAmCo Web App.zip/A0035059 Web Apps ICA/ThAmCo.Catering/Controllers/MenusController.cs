﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ThAmCo.Catering.Dtos;
using ThAmCo.Catering.Models;

namespace ThAmCo.Catering.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenusController : ControllerBase
    {
        private readonly CateringContext _context;

        public MenusController(CateringContext context)
        {
            _context = context;
        }

        // GET: api/Menus
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Menu>>> Getmenus()
        {
            return await _context.menus.ToListAsync();
        }

        // GET: api/Menus/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Menu>> GetMenu(int id)
        {
            var menu = await _context.menus.FindAsync(id);

            if (menu == null)
            {
                return NotFound();
            }

            return menu;
        }

        // GET: api/Menus/GetFoodBookings/2
        [HttpGet("GetFoodBookings/{id}")]
        public async Task<ActionResult<IEnumerable<FoodBookingDTO>>> GetFoodBookings(int id)
        {
            var foodBooking = await _context
                .foodBookings
                .Where(p => p.MenuId == id)
                .Include(p => p.Menu)
                .Select(p => new FoodBookingDTO
                {
                    ClientReferenceId = p.ClientReferenceId,
                    MenuId = p.MenuId,
                    FoodBookingId = p.FoodBookingId,
                    NumberOfGuests = p.NumberOfGuests
                }
                )
                .ToListAsync();
            return foodBooking;
        }

        // GET: api/Menus/GetMenuFoodItems/2
        [HttpGet("GetMenuFoodItems/{id}")]
        public async Task<ActionResult<IEnumerable<MenuFoodItemDTO>>> GetMenuFoodItems(int id)
        {
            var menuFoodItem = await _context
                .menuFoodItems
                .Where(p => p.MenuId == id)
                .Include(p => p.Menu)
                .Select(p => new MenuFoodItemDTO
                {
                    MenuId = p.MenuId,
                    FoodItemId = p.FoodItemId
                })
                .ToListAsync();
            return menuFoodItem;
        }

        // PUT: api/Menus/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutMenu(int id, Menu menu)
        {
            if (id != menu.MenuId)
            {
                return BadRequest();
            }

            _context.Entry(menu).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MenuExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Menus
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Menu>> PostMenu(Menu menu)
        {
            if(_context.menus.Where(m => m.MenuName == menu.MenuName).FirstOrDefault() != null)
            {
                return BadRequest();
            }

            _context.menus.Add(menu);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetMenu", new { id = menu.MenuId }, menu);
        }

        // DELETE: api/Menus/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Menu>> DeleteMenu(int id)
        {
            var menu = await _context.menus.FindAsync(id);
            if (menu == null)
            {
                return NotFound();
            }

            _context.menus.Remove(menu);
            await _context.SaveChangesAsync();

            return menu;
        }

        private bool MenuExists(int id)
        {
            return _context.menus.Any(e => e.MenuId == id);
        }
    }
}
