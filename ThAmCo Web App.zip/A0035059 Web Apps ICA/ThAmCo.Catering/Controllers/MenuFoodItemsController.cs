﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ThAmCo.Catering.Dtos;
using ThAmCo.Catering.Models;

namespace ThAmCo.Catering.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenuFoodItemsController : ControllerBase
    {
        private readonly CateringContext _context;

        public MenuFoodItemsController(CateringContext context)
        {
            _context = context;
        }

        // GET: api/MenuFoodItems
        [HttpGet]
        public async Task<ActionResult<IEnumerable<MenuFoodItem>>> GetmenuFoodItems()
        {
            var menuFoodItem = await _context
                .menuFoodItems
                .Select(x => new MenuFoodItemDTO
                {
                    FoodItemId = x.FoodItemId,
                    MenuId = x.MenuId
                }
                ).ToListAsync();
            return Ok(menuFoodItem);
            //return await _context.menuFoodItems.ToListAsync();
        }

        // GET: api/MenuFoodItems/5
        [HttpGet("{id}")]
        public async Task<ActionResult<MenuFoodItem>> GetMenuFoodItem(int id)
        {
            var menuFoodItem = await _context
                .menuFoodItems
                .Where(p => p.MenuId == id)
                .Select(x => new MenuFoodItemDTO
                {
                    FoodItemId = x.FoodItemId,
                    MenuId = x.MenuId
                }
                ).ToListAsync();
            

            if (menuFoodItem == null)
            {
                return NotFound();
            }
            return Ok(menuFoodItem);
        }


        // PUT: api/MenuFoodItems/5,5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{menuId},{foodId}")]
        public async Task<IActionResult> PutMenuFoodItem(int menuId, int foodId, MenuFoodItem menuFoodItem)
        {
            if (menuId != menuFoodItem.MenuId && foodId != menuFoodItem.FoodItemId)
            {
                return BadRequest();
            }

            _context.Entry(menuFoodItem).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MenuFoodItemExists(menuId) || !MenuFoodItemExists(foodId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/MenuFoodItems
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<MenuFoodItem>> PostMenuFoodItem(MenuFoodItem menuFoodItem)
        {
            _context.menuFoodItems.Add(menuFoodItem);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (MenuFoodItemExists(menuFoodItem.FoodItemId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetMenuFoodItem", new { id = menuFoodItem.FoodItemId }, menuFoodItem);
        }

        // DELETE: api/MenuFoodItems/5,5
        [HttpDelete("{menuId},{foodId}")]
        public async Task<ActionResult<MenuFoodItem>> DeleteMenuFoodItem(int menuId, int foodId)
        {
            var menuFoodItem = await _context.menuFoodItems.FindAsync(menuId, foodId);
            if (menuFoodItem == null)
            {
                return NotFound();
            }

            _context.menuFoodItems.Remove(menuFoodItem);
            await _context.SaveChangesAsync();

            return menuFoodItem;
        }

        private bool MenuFoodItemExists(int id)
        {
            return _context.menuFoodItems.Any(e => e.FoodItemId == id);
        }
    }
}
