﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThAmCo.Catering.Migrations
{
    public partial class moreData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "menus",
                columns: new[] { "MenuId", "MenuName" },
                values: new object[,]
                {
                    { 1, "Starter Menu" },
                    { 2, "Mains Menu" },
                    { 3, "Desert Menu" },
                    { 4, "Drinks Menu" }
                });

            migrationBuilder.InsertData(
                table: "foodBookings",
                columns: new[] { "FoodBookingId", "ClientReferenceId", "MenuId", "NumberOfGuests" },
                values: new object[,]
                {
                    { 1, 1, 1, 2 },
                    { 2, 2, 1, 5 },
                    { 5, 5, 2, 4 },
                    { 3, 3, 3, 1 },
                    { 4, 4, 4, 2 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "foodBookings",
                keyColumn: "FoodBookingId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "foodBookings",
                keyColumn: "FoodBookingId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "foodBookings",
                keyColumn: "FoodBookingId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "foodBookings",
                keyColumn: "FoodBookingId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "foodBookings",
                keyColumn: "FoodBookingId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "menus",
                keyColumn: "MenuId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "menus",
                keyColumn: "MenuId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "menus",
                keyColumn: "MenuId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "menus",
                keyColumn: "MenuId",
                keyValue: 4);
        }
    }
}
