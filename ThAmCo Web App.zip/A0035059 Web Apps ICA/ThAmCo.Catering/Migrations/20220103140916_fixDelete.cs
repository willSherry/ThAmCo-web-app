﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThAmCo.Catering.Migrations
{
    public partial class fixDelete : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings");

            migrationBuilder.AlterColumn<string>(
                name: "MenuName",
                table: "menus",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<int>(
                name: "MenuId",
                table: "foodBookings",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings",
                column: "MenuId",
                principalTable: "menus",
                principalColumn: "MenuId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings");

            migrationBuilder.AlterColumn<string>(
                name: "MenuName",
                table: "menus",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<int>(
                name: "MenuId",
                table: "foodBookings",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings",
                column: "MenuId",
                principalTable: "menus",
                principalColumn: "MenuId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
