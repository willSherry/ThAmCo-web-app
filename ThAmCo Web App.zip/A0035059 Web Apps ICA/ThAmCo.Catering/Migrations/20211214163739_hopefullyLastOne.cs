﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThAmCo.Catering.Migrations
{
    public partial class hopefullyLastOne : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 2,
                column: "Description",
                value: "Burger");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 2,
                column: "Description",
                value: "Borger");
        }
    }
}
