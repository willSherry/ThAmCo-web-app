﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThAmCo.Catering.Migrations
{
    public partial class relationshipTest : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "UnitPrice",
                table: "foodItems",
                nullable: false,
                oldClrType: typeof(float),
                oldType: "real");

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 1,
                column: "UnitPrice",
                value: 0m);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 2,
                column: "UnitPrice",
                value: 0m);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 3,
                column: "UnitPrice",
                value: 0m);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 4,
                column: "UnitPrice",
                value: 0m);

            migrationBuilder.CreateIndex(
                name: "IX_menuFoodItems_MenuId",
                table: "menuFoodItems",
                column: "MenuId");

            migrationBuilder.CreateIndex(
                name: "IX_foodBookings_MenuId",
                table: "foodBookings",
                column: "MenuId");

            migrationBuilder.AddForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings",
                column: "MenuId",
                principalTable: "menus",
                principalColumn: "MenuId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_menuFoodItems_foodItems_FoodItemId",
                table: "menuFoodItems",
                column: "FoodItemId",
                principalTable: "foodItems",
                principalColumn: "FoodItemId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_menuFoodItems_menus_MenuId",
                table: "menuFoodItems",
                column: "MenuId",
                principalTable: "menus",
                principalColumn: "MenuId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings");

            migrationBuilder.DropForeignKey(
                name: "FK_menuFoodItems_foodItems_FoodItemId",
                table: "menuFoodItems");

            migrationBuilder.DropForeignKey(
                name: "FK_menuFoodItems_menus_MenuId",
                table: "menuFoodItems");

            migrationBuilder.DropIndex(
                name: "IX_menuFoodItems_MenuId",
                table: "menuFoodItems");

            migrationBuilder.DropIndex(
                name: "IX_foodBookings_MenuId",
                table: "foodBookings");

            migrationBuilder.AlterColumn<float>(
                name: "UnitPrice",
                table: "foodItems",
                type: "real",
                nullable: false,
                oldClrType: typeof(decimal));

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 1,
                column: "UnitPrice",
                value: 0f);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 2,
                column: "UnitPrice",
                value: 0f);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 3,
                column: "UnitPrice",
                value: 0f);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 4,
                column: "UnitPrice",
                value: 0f);
        }
    }
}
