﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThAmCo.Catering.Migrations
{
    public partial class evenMoreData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings");

            migrationBuilder.DropForeignKey(
                name: "FK_menuFoodItems_foodItems_FoodItemId",
                table: "menuFoodItems");

            migrationBuilder.DropForeignKey(
                name: "FK_menuFoodItems_menus_MenuId",
                table: "menuFoodItems");

            migrationBuilder.AlterColumn<float>(
                name: "UnitPrice",
                table: "foodItems",
                nullable: false,
                oldClrType: typeof(double),
                oldType: "float");

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 1,
                column: "UnitPrice",
                value: 1.5f);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 2,
                column: "UnitPrice",
                value: 3.5f);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 3,
                column: "UnitPrice",
                value: 1f);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 4,
                column: "UnitPrice",
                value: 8.5f);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 5,
                column: "UnitPrice",
                value: 3.5f);

            migrationBuilder.InsertData(
                table: "menuFoodItems",
                columns: new[] { "FoodItemId", "MenuId" },
                values: new object[,]
                {
                    { 1, 1 },
                    { 2, 2 },
                    { 3, 3 }
                });

            migrationBuilder.AddForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings",
                column: "MenuId",
                principalTable: "menus",
                principalColumn: "MenuId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_menuFoodItems_menus_FoodItemId",
                table: "menuFoodItems",
                column: "FoodItemId",
                principalTable: "menus",
                principalColumn: "MenuId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_menuFoodItems_foodItems_MenuId",
                table: "menuFoodItems",
                column: "MenuId",
                principalTable: "foodItems",
                principalColumn: "FoodItemId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings");

            migrationBuilder.DropForeignKey(
                name: "FK_menuFoodItems_menus_FoodItemId",
                table: "menuFoodItems");

            migrationBuilder.DropForeignKey(
                name: "FK_menuFoodItems_foodItems_MenuId",
                table: "menuFoodItems");

            migrationBuilder.DeleteData(
                table: "menuFoodItems",
                keyColumns: new[] { "FoodItemId", "MenuId" },
                keyValues: new object[] { 1, 1 });

            migrationBuilder.DeleteData(
                table: "menuFoodItems",
                keyColumns: new[] { "FoodItemId", "MenuId" },
                keyValues: new object[] { 2, 2 });

            migrationBuilder.DeleteData(
                table: "menuFoodItems",
                keyColumns: new[] { "FoodItemId", "MenuId" },
                keyValues: new object[] { 3, 3 });

            migrationBuilder.AlterColumn<double>(
                name: "UnitPrice",
                table: "foodItems",
                type: "float",
                nullable: false,
                oldClrType: typeof(float));

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 1,
                column: "UnitPrice",
                value: 1.5);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 2,
                column: "UnitPrice",
                value: 3.5);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 3,
                column: "UnitPrice",
                value: 1.0);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 4,
                column: "UnitPrice",
                value: 8.5);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 5,
                column: "UnitPrice",
                value: 3.5);

            migrationBuilder.AddForeignKey(
                name: "FK_foodBookings_menus_MenuId",
                table: "foodBookings",
                column: "MenuId",
                principalTable: "menus",
                principalColumn: "MenuId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_menuFoodItems_foodItems_FoodItemId",
                table: "menuFoodItems",
                column: "FoodItemId",
                principalTable: "foodItems",
                principalColumn: "FoodItemId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_menuFoodItems_menus_MenuId",
                table: "menuFoodItems",
                column: "MenuId",
                principalTable: "menus",
                principalColumn: "MenuId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
