﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThAmCo.Catering.Migrations
{
    public partial class fixData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<double>(
                name: "UnitPrice",
                table: "foodItems",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)");

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 1,
                column: "UnitPrice",
                value: 1.5);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 2,
                column: "UnitPrice",
                value: 3.5);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 3,
                column: "UnitPrice",
                value: 1.0);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 4,
                column: "UnitPrice",
                value: 8.5);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 5,
                column: "UnitPrice",
                value: 3.5);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "UnitPrice",
                table: "foodItems",
                type: "decimal(18,2)",
                nullable: false,
                oldClrType: typeof(double));

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 1,
                column: "UnitPrice",
                value: 0m);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 2,
                column: "UnitPrice",
                value: 0m);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 3,
                column: "UnitPrice",
                value: 0m);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 4,
                column: "UnitPrice",
                value: 0m);

            migrationBuilder.UpdateData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 5,
                column: "UnitPrice",
                value: 5m);
        }
    }
}
