﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThAmCo.Catering.Migrations
{
    public partial class test2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "foodItems",
                columns: new[] { "FoodItemId", "Description", "UnitPrice" },
                values: new object[] { 5, "Pie", 5m });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "foodItems",
                keyColumn: "FoodItemId",
                keyValue: 5);
        }
    }
}
