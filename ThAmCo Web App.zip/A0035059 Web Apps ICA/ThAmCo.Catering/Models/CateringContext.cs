﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ThAmCo.Catering.Models
{
    public class CateringContext : DbContext
    {
        public DbSet<FoodBooking> foodBookings { get; set; }
        public DbSet<FoodItem> foodItems { get; set; }
        public DbSet<Menu> menus { get; set; }
        public DbSet<MenuFoodItem> menuFoodItems { get; set; }


        public CateringContext(DbContextOptions<CateringContext> options) : base(options)
        { 
        }
    

        protected override void OnModelCreating(ModelBuilder builder)
        {
            

            base.OnModelCreating(builder);

            // Prevent Cascade Delete
            builder.Entity<FoodBooking>()
                .HasOne(m => m.Menu)
                .WithMany()
                .HasForeignKey(m => m.MenuId)
                .OnDelete(DeleteBehavior.Cascade);

            


            // Composite Key
            builder.Entity<MenuFoodItem>()
                .HasKey(a => new { a.FoodItemId, a.MenuId });

            // Handle the many to many
            builder.Entity<MenuFoodItem>()
                .HasOne(a => a.FoodItem)
                .WithMany()
                .HasForeignKey(a => a.MenuId);


            builder.Entity<MenuFoodItem>()
                .HasOne(a => a.Menu)
                .WithMany()
                .HasForeignKey(a => a.FoodItemId);

            

            // Seed Data
            builder.Entity<FoodItem>().HasData(
                new FoodItem { FoodItemId = 1, Description = "Hot Dog", UnitPrice = 1.5f },
                new FoodItem { FoodItemId = 2, Description = "Burger", UnitPrice = 3.5f },
                new FoodItem { FoodItemId = 3, Description = "Doughnut", UnitPrice = 1f },
                new FoodItem { FoodItemId = 4, Description = "Pizza", UnitPrice = 8.5f },
                new FoodItem { FoodItemId = 5, Description = "Pie", UnitPrice = 3.5f}
                );
            
            builder.Entity<Menu>().HasData(
                new Menu { MenuId = 1, MenuName = "Starter Menu"},
                new Menu { MenuId = 2, MenuName = "Mains Menu" },
                new Menu { MenuId = 3, MenuName = "Desert Menu" },
                new Menu { MenuId = 4, MenuName = "Drinks Menu" }
                );

            builder.Entity<FoodBooking>().HasData(
                new FoodBooking { ClientReferenceId = 1, FoodBookingId = 1, NumberOfGuests = 2, MenuId = 1},
                new FoodBooking { ClientReferenceId = 2, FoodBookingId = 2, NumberOfGuests = 5, MenuId = 1},
                new FoodBooking { ClientReferenceId = 3, FoodBookingId = 3, NumberOfGuests = 1, MenuId = 3},
                new FoodBooking { ClientReferenceId = 4, FoodBookingId = 4, NumberOfGuests = 2, MenuId = 4},
                new FoodBooking { ClientReferenceId = 5, FoodBookingId = 5, NumberOfGuests = 4, MenuId = 2}
                ) ;

            builder.Entity<MenuFoodItem>().HasData(
                new MenuFoodItem { FoodItemId = 1, MenuId = 2},
                new MenuFoodItem { FoodItemId = 2, MenuId = 2 },
                new MenuFoodItem { FoodItemId = 3, MenuId = 3 }
                );

        }

    }
}


    
