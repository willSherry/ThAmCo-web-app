﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ThAmCo.Catering.Dtos
{
    public class MenuFoodItemDTO
    {
        public int MenuId{ get; set; }

        public int FoodItemId { get; set; }
            
    }
}
