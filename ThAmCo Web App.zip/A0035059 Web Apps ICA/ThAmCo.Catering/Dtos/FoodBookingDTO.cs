﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ThAmCo.Catering.Dtos
{
    public class FoodBookingDTO
    {
        public FoodBookingDTO()
        {

        }

        public int FoodBookingId{ get; set; }

        public int ClientReferenceId{ get; set; }

        public int NumberOfGuests{ get; set; }

        public int? MenuId { get; set; }
    }
}
